# TKMGUI V2.1.1
**Currently, only for the development of the preview version**

![mit](https://img.shields.io/badge/license-MIT-blue)![python: v3.8.5](https://img.shields.io/badge/python-v3.8.5-green)![pyqt](https://img.shields.io/badge/Qt5-v5.14.3-red)<a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=PFZTVFJPWU5aEU9ZWVh8WlNEUV1VUBJfU1E" style="text-decoration:none;"><img src="http://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_11.png"/></a>

[English](README-EN.md) [简体中文](README.md)

![preview](https://tvax1.sinaimg.cn/large/006908GAly1gytdof69rrj30p00godhe.jpg)

